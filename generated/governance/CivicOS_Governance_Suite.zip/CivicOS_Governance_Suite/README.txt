CivicOS Institute Governance Document Suite
Version: 1.0
Generated: 2026-02-28T20:19:14.270Z
Status: All documents DRAFT — Pending Board Adoption
Contact: NCerbone@civicos-institute.org
