CivicOS Institute Governance Document Suite
Version: 1.0
Generated: 2026-02-28T21:27:46.191Z
Status: All documents DRAFT — Pending Board Adoption
Contact: NCerbone@civicos-institute.org
