CivicOS Institute Governance Document Suite
Version: 1.0
Generated: 2026-02-28T20:46:44.907Z
Status: All documents DRAFT — Pending Board Adoption
Contact: NCerbone@civicos-institute.org
